from django.db import models

class volunteers(models.Model):
    name =models.CharField(max_length=100, blank=True, null=True)
    email =models.EmailField()
    phone =models.CharField(max_length=17,blank=True)
    location=models.CharField(max_length=50, blank=True, null=True)
    comment =models.TextField(default="user message")
    created_at=models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return f"{self.name}"



class UserData(models.Model):
    firstname = models.CharField(max_length=100, blank=True, null=True)
    middlename = models.CharField(max_length=100, blank=True, null=True)  # Fixed typo in CharField
    email = models.EmailField()  # Made email unique to prevent duplicates
    message = models.TextField(default="user message")
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return f"{self.firstname} {self.middlename}".strip()  # Improved string representation

