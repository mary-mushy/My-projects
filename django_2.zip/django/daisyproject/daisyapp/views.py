
from .models import UserData,volunteers
from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib import messages




# Create your views here.


def index(request):
    return render(request,'index.html')

def donate(request):
    return render(request,'donate.html')

def sendinfo(request):
    if request.method == "POST":
        name = request.POST['name']
        email=request.POST['volunteer-email']
        phonenumber=request.POST['phone']
        location=request.POST['location']
        commentsection=request.POST['comment-section']
        params =volunteers.objects.create(
            name = name,
            email = email,
            phonenumber = phonenumber,
            location = location,
            commentsection = commentsection
        )
        params.save()
        messages.success(request,'you have sucessfully registered as volunteer')
        return redirect('index')
    return render(request,'index.html')

def senddata(request):
    if request.method == "POST":
        firstname = request.POST['first-name']
        middlename = request.POST['last-name']
        message = request.POST['message']
        email = request.POST['email']
        params = UserData.objects.create(
            firstname = firstname,
            middlename = middlename,
            email=email,
            message=message
        )
        params.save()
        print(params)
        messages.success(request,'You successfully add data')
        return redirect('index')
    return render(request,'index.html')
