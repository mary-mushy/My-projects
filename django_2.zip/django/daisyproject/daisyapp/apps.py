from django.apps import AppConfig


class DaisyappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'daisyapp'
