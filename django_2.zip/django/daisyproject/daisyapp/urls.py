from django.conf import settings
from django.urls import path
from . import views

urlpatterns =[
    path('',views.index,name='index'),
    path('pay/',views.donate,name='pay'),
    path('userdata/',views.senddata,name='userdata'),
    path('userinfo/',views.sendinfo,name='userinfo'),
    path('volunteer/',views.volunteers,name='volunteer')
]

